<?php

const baz = NULL;
